/*
Ubidots.cpp -El objetivo de la librería es realizar la conexión con la plataforma ubidots, para que los usuarios puedan postear o escribir su información 
en la nube


*/
#ifndef Ubidots_arduinoYUN_h
#define Ubidots_arduinoYUN_h
#include "arduino.h"
#include <Process.h>

class Ubidots {
  public:
   Ubidots(String token);
   String get_value(String idvariable);
   boolean save_value(String idvariable,String valor);  
   boolean save3_values(String idvariable,String valor,String idvariable2,String valor2,String idvariable3,String valor3);    

 
  private: 
   
   int flag;    	
   String token;
   char c;
   String value;
};

#endif