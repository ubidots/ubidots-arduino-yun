/*
Ubidots.cpp -El objetivo de la librería es realizar la conexión con la plataforma ubidots, para que los usuarios puedan postear o escribir su información 
en la nube

*/
/*
Ubidots Library with get_value, save_value functions, for  users to be able post or read the information in the Cloud


Created 9 Jun 2014
Modified 9 Jun 2014
by Mateo Vélez

*/

#include "arduino.h"
#include "Ubidots_arduinoYUN.h"
#include <Process.h>
//----------------------------------------------------------------------------------------
//--------------------------------------Ready to use the API------------------------------
//----------------------------------------------------------------------------------------
Ubidots::Ubidots(String apikey)
{
  apikey = apikey;
  flag = 0;
  token = "";
  value = "";
}
//----------------------------------------------------------------------------------------
//-----------------------------------Get Value from Ubidots!------------------------------
//----------------------------------------------------------------------------------------

/*This functions is for get value from Ubidots, you need send the id variable that you want
to ask to the server.

The function discriminates the value of the variable using a state machine, this in order 
to avoid many changes in each new version of the API.

*/
String Ubidots::get_value(String idvariable)
{  
   char TOKEN[9] = {'"', 'v', 'a', 'l', 'u', 'e', '"', ':', ' '};
  int i = 0;
  char valor[7];  
  value = "";
  Process ubidots;
  Console.print("\n\nGet data... ");

  ubidots.begin("lua");
  ubidots.addParameter("/root/ubidots_get.lua");
  ubidots.addParameter(token);
  ubidots.addParameter(idvariable);
  ubidots.run();
  Console.println("done!");


  // If there's incoming data from the net connection,
  // send it out the Serial:
  flag = 0;
  while (value == "")
  {
    while (!ubidots.available());
    while (ubidots.available() > 0) {
      char c = ubidots.read();
    
      if (c == TOKEN[flag])
      {
        flag++;
        
        
      }
      else if (((c>47)&&(c<58)||(c=='.')||(c=='}'))&&(flag>8))
      {
        
        if(c=='.')
          {
            flag = 50;
            break;
          }
          else
          {
            value += c;
            flag++;
          }
      }
      else if (flag!=50)
      {
        flag = 0;
      }
             
  }
   

    break;
  } ubidots.flush();
 
  return value;
  
}

//----------------------------------------------------------------------------------------
//------------------------------------POST Value to Ubidots!------------------------------
//----------------------------------------------------------------------------------------

/*This function is to post the variable value to Ubidots, you need send the id of the variable
and the value that you want post on the server.


The function returns  true or false depending on whether the posting is completed or not
*/
boolean Ubidots::save_value(String idvariable,String valor)
{
  char Http[9] = {'H', 'T', 'T', 'P', '/', '1', '.', '1', ' '};
  flag = 0;

  Process ubidots;
  Console.print("\n\nSending data... ");

  ubidots.begin("lua");
  ubidots.addParameter("/root/ubidots_post.lua");
  ubidots.addParameter(valor);
  ubidots.addParameter(token);
  ubidots.addParameter(idvariable);
  ubidots.run();
  Console.println("done!");


  // If there's incoming data from the net connection,
  // send it out the Serial:
  while (!ubidots.available());
  while (ubidots.available() > 0) {
    char c = ubidots.read();


    if ((Http[flag] == c) && (flag < 9))
    {
      flag++;
    }
    else if ((flag > 8) && (flag < 12))
    {
      value += c;
      flag++;
    }
    else
    {
      flag = 0;
    }

    if (value == "500")
    {
      return false;
      break;
    }
  }

  if (value == "201" || value == "200")
  {
    return true;
  }
  else
  {
    return false;
  }
}

//---------------------------------------------------------------------------------------

boolean Ubidots::save3_values(String idvariable,String valor,String idvariable2,String valor2,String idvariable3,String valor3)
{
  char Http[9] = {'H', 'T', 'T', 'P', '/', '1', '.', '1', ' '};
  flag = 0;

  Process ubidots;
  Console.print("\n\nSending data... ");

  ubidots.begin("lua");
  ubidots.addParameter("/root/ubidots_post3.lua");
  ubidots.addParameter(valor);
  ubidots.addParameter(token);
  ubidots.addParameter(idvariable);
  ubidots.addParameter(valor2);
  ubidots.addParameter(idvariable2);
  ubidots.addParameter(valor3);
  ubidots.addParameter(idvariable3);
  ubidots.run();
  Console.println("done!");


  // If there's incoming data from the net connection,
  // send it out the Serial:
  while (!ubidots.available());
  while (ubidots.available() > 0) {
    char c = ubidots.read();


    if ((Http[flag] == c) && (flag < 9))
    {
      flag++;
    }
    else if ((flag > 8) && (flag < 12))
    {
      value += c;
      flag++;
    }
    else
    {
      flag = 0;
    }

    if (value == "500")
    {
      return false;
      break;
    }
  }

  if (value == "201" || value == "200")
  {
    return true;
  }
  else
  {
    return false;
  }
}

//---------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------
//-------------------------Create a Token for your variable!------------------------------
//----------------------------------------------------------------------------------------

/*This function is to create a token for your connection with the server.


The function returns  true or false depending on whether the connection  is completed or not

*/
